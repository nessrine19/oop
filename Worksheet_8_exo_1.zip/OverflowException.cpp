#include "OverflowException.h"


OverflowException::OverflowException(std::string msg) : MathException(msg)
{

}

