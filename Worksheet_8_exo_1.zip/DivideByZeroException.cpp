#include "DivideByZeroException.h"

DivideByZeroException::DivideByZeroException(std::string msg) : MathException(msg)
{

}

