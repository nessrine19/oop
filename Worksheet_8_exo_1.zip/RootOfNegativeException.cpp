#include "RootOfNegativeException.h"

RootOfNegativeException::RootOfNegativeException(std::string msg) : MathException(msg)
{

}

